const baseUrl = 'https://api.football-data.org/v2/';
const token = '4017be1b893b48f3904bfc91a803fc77';

module.exports = {
  baseUrl, token,
};
