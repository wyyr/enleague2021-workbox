// workbox.core.skipWaiting();
// workbox.core.clientsClaim();


//     {
//       urlPattern: new RegExp('/'),
//       handler: 'CacheFirst',
//       method: 'GET',
//       options: {
//         cacheName: 'Runtime',
//         expiration: {
//           maxAgeSeconds: 60 * 60 * 24,
//         },
//       },
//     },
//     {
//       urlPattern: new RegExp('https://api.football-data.org/v2/'),
//       handler: 'StaleWhileRevalidate',
//       method: 'GET',
//       options: {
//         cacheName: 'Football API',
//         expiration: {
//           maxAgeSeconds: 60 * 60 * 24,
//           maxEntries: 60,
//         },
//       },
//     },

self.addEventListener('push', function(event) {
  let body;
  if (event.data) {
    body = event.data.text();
  } else {
    body = 'Push message no payload';
  }
  const options = {
    body: body,
    icon: './src/assets/icons/notification.png',
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1,
    },
  };
  event.waitUntil(
      self.registration.showNotification('Hai, This is Notification', options),
  );
});

// workbox.precaching.precacheAndRoute(self.__precacheManifest);
